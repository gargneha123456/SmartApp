package com.example.recyclerview;

public class Complaint {
    String Department;
    String Status;
    String Content;
    String Author;
    int upvotes;


    public Complaint(String department,  String content, String author,String status ) {
        Department = department;
        Status = status;
        Content = content;
        Author = author;
        upvotes = 0;
    }

    public int getUpvotes() {
        return upvotes;
    }

    public void setUpvotes(int upvotes) {
        this.upvotes = upvotes;
    }

    public String getDepartment() {
        return Department;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public void setDepartment(String department) {
        Department = department;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String author) {
        Author = author;
    }
}
