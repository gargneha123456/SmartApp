package com.example.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ComplaintAdapter extends RecyclerView.Adapter<ComplaintAdapter.ViewHolder> //data in triangle brackets is added after creating viewholder class
{
    private ArrayList<Complaint> list_items;
    ItemClicked activity;

    public interface ItemClicked
    {
        void onItemClicked( int i );
    }

    public ComplaintAdapter(Context context, ArrayList<Complaint> list) { //context tells the activity using it

        list_items = list;
        activity = (ItemClicked) context;  //we can do this because main activity implements this interface and thus there is a connection
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvAuth, tvContent, tvDept, tvStatus, tvUp;
        ImageView ivPic, ivAuth;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvAuth = itemView.findViewById(R.id.tvAuth);
            tvContent = itemView.findViewById(R.id.tvContent);
            ivPic = itemView.findViewById(R.id.ivPic);
            tvDept = itemView.findViewById(R.id.tvDept);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            ivAuth = itemView.findViewById(R.id.ivAuth);
            tvUp = itemView.findViewById(R.id.tvUp);

            itemView.setOnClickListener(new View.OnClickListener() {  //what happens when item in a list is clicked
                @Override
                public void onClick(View v) {
                    activity.onItemClicked(list_items.indexOf((Complaint)v.getTag()));
                }
            });
        }
    }

    @NonNull
    @Override
    public ComplaintAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { //when data in triangle brackets is added.. change recyclerview to complaintadapter

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);

        return new ViewHolder(v); //because return type is of type ViewHolder
    }

    @Override
    public void onBindViewHolder(@NonNull ComplaintAdapter.ViewHolder holder, int position) { //runs for every item in list

        holder.itemView.setTag(list_items.get(position));  //setting tag for use in onClick method
        holder.ivPic.setImageResource(R.drawable.ic_launcher_foreground);
        holder.ivAuth.setImageResource(R.drawable.ic_launcher_background);
        holder.tvAuth.setText(list_items.get(position).getAuthor());
        holder.tvContent.setText(list_items.get(position).getContent());
        holder.tvDept.setText(list_items.get(position).getDepartment());
        holder.tvStatus.setText(list_items.get(position).getStatus());
        holder.tvUp.setText("+" + list_items.get(position).getUpvotes() + " others");


    }

    @Override
    public int getItemCount() {
        return list_items.size();
    }
}
