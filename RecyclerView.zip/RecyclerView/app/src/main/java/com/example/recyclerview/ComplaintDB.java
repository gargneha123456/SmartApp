package com.example.recyclerview;

public class ComplaintDB {
    public static final String KEY_ROWID = "_id";             //names of columns
    public static final String KEY_DEPT = "_dept";            //underscore in name is imp.
    public static final String KEY_STATUS = "_status";
    public static final String KEY_CONTENT = "_content";
    public static final String KEY_AUTHOR = "_author";
    public static final String KEY_UP = "_upvotes";
    public static final String KEY_LOC = "_loc";


}
