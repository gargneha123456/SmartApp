package com.example.recyclerview;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ComplaintAdapter.ItemClicked {
    RecyclerView recyclerView;
    RecyclerView.Adapter myAdapter;
    RecyclerView.LayoutManager layoutManager;


    ArrayList<Complaint> list;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        recyclerView = findViewById(R.id.list);
        recyclerView.setHasFixedSize(true);

        //can use  button which adds another elemnt in arraylist and use myAdapter.notifydatachanged.. something to update dynamically

        layoutManager = new LinearLayoutManager(this);
        //layoutManager = new LinearLayoutManager( this, LinearLayoutManager.HORIZONTAL, false);
        //layoutManager = new GridLayoutManager(this, 3, GridLayoutManager.HORIZONTAL, false);



        recyclerView.setLayoutManager(layoutManager);
        list = new ArrayList<Complaint>();
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));
        list.add(new Complaint("Municipality","Electricity not available since last 3 hours.", "Ram", "RESOLVED"));



        myAdapter = new ComplaintAdapter(this, list);
        recyclerView.setAdapter(myAdapter);
    }



    @Override
    public void onItemClicked(int i) {
        Toast.makeText(this, list.get(i).getContent(), Toast.LENGTH_SHORT).show();
    }
}
